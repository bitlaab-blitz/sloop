const std = @import("std");

const Sloop = @import("sloop").Sloop;


pub fn main(init: std.process.Init) !void {
    var gpa_mem = std.heap.DebugAllocator(.{}).init;
    defer std.debug.assert(gpa_mem.deinit() == .ok);
    const heap = gpa_mem.allocator();

    // Connection pool — `workers = null` opens one connection per available
    // CPU core (pass a count to match the executor's worker count instead);
    // `cache` is the per-connection storage engine cache size in MB.
    // In-memory storage (`null` path) collapses the pool to a single connection
    var sloop = try Sloop.init(init.io, heap, "bucket.db", 32, null);
    try sloop.setIndex();
    defer sloop.deinit();

    // Full consistency check of the storage file (O(database size)) —
    // typically run once on startup or from a periodic maintenance job
    try sloop.checkIntegrity();

    var bucket = sloop.bucket();

    try bucket.create("test_img1");
    try bucket.create("test_img2");
    try bucket.create("test_img3");

    try bucket.remove("test_img3");

    const items = try bucket.list();
    defer bucket.freeList(items);

    for (items) |item| { std.debug.print("{s}\n", .{item}); }

    var obj = sloop.object();

    // Puts a complete (public) object into the bucket and reads it back
    const put_uuid = try obj.put(
        "test_img1", "put.txt", "Hello, Sloop!", &.{}, &.{}
    );
    const blob = try obj.get("test_img1", &put_uuid, null, .default);
    defer sloop.heap.free(blob);
    std.debug.print("{s}\n", .{blob});

    try obj.remove("test_img1", &put_uuid, null, .default);

    // Upserts under a caller-supplied identity — the uuid and creation
    // timestamp are owned by the caller (replica/sync flows) and stored
    // as-is, without validation
    const sync_urn = "0199c0a8-7d1e-7f3a-9b2c-4d5e6f708192";

    try obj.putWith(
        "test_img2", sync_urn, "synced.txt", "Synced, Sloop!",
        &.{"john"}, &.{"jane"}, 1730000000
    );

    const synced = try obj.get("test_img2", sync_urn, "jane", .default);
    defer sloop.heap.free(synced);
    std.debug.print("{s}\n", .{synced});

    // Re-pushing the same uuid overwrites the record in place — the owner
    // and access lists are replaced with the given ones
    try obj.putWith(
        "test_img2", sync_urn, "synced2.txt", "Replaced!",
        &.{"john"}, &.{}, 1730000001
    );

    var sync_info = try obj.info("test_img2", sync_urn, "john", .default);
    defer sync_info.free();
    std.debug.print("Synced: {s} | {d} bytes\n", .
        {sync_info.value().name, sync_info.value().size});

    // Pre-sizes a zero blob under the caller-supplied uuid for incremental
    // writes (same stream rules as `provision()`)
    const upload_urn = "0199c0a8-7d1e-7f3a-9b2c-4d5e6f708193";

    try obj.provisionWith(
        "test_img2", upload_urn, "upload.bin", 64,
        &.{"john"}, &.{"jane"}, 1730000002
    );

    var upload_info = try obj.info("test_img2", upload_urn, "john", .default);
    defer upload_info.free();

    {
        const rid = upload_info.value().rowid;
        var uploader = try obj.openStream(
            "test_img2", rid, upload_urn, "john", .default
        );
        defer Sloop.Object.closeStream(&uploader);

        try Sloop.Object.incWrite(&uploader, "sloop", 0);
    }

    const uploaded = try obj.get("test_img2", upload_urn, "john", .default);
    defer sloop.heap.free(uploaded);
    std.debug.print("Uploaded: {s}\n", .{uploaded[0..5]});

    // Creates a provisional object in the bucket

    // Private object
    const uuid = try obj.provision("test_img1", "prov.txt", 1024,
        &.{"john"}, &.{"jane"}
    );
    std.debug.print("{s}\n", .{uuid});

    // Public object
    const uuid2 = try obj.provision("test_img1", "prov.txt", 1024, &.{}, &.{});
    std.debug.print("{s}\n", .{uuid2});

    // Gets object info from the bucket

    // Private object — only owners are permitted
    var info = try obj.info("test_img1", &uuid, "john", .default);
    defer info.free();

    std.debug.print("Info: {s} | {d} bytes\n", .
        {info.value().name, info.value().size});

    // Public object — readable without an entity
    var info2 = try obj.info("test_img1", &uuid2, null, .default);
    defer info2.free();

    std.debug.print("Info: {s} | {d} bytes\n", .
        {info2.value().name, info2.value().size});

    // Incrementally writes into the provisional object (owner stream —
    // owners hold read-write streams) and reads it back out. Streams hold
    // their pooled connection until closed, so scope them before mutating
    // the record again
    {
        const rid = info.value().rowid;
        var blob_writer = try obj.openStream("test_img1", rid, &uuid, "john", .default);
        defer Sloop.Object.closeStream(&blob_writer);

        try Sloop.Object.incWrite(&blob_writer, "hello", 2);

        // Incrementally reads out of the provisional object (access stream —
        // access entities hold read-only streams)
        var blob_reader = try obj.openStream("test_img1", rid, &uuid, "jane", .default);
        defer Sloop.Object.closeStream(&blob_reader);

        var buffer: [128]u8 = undefined;
        const head = (try Sloop.Object.incRead(&blob_reader, &buffer)).?;
        std.debug.print("Chunk: {s}\n", .{head});

        // A buffer larger than the remaining data yields a partial read
        var big: [2048]u8 = undefined;
        const tail = (try Sloop.Object.incRead(&blob_reader, &big)).?;
        std.debug.print("Tail: {d} bytes\n", .{tail.len});

        if (try Sloop.Object.incRead(&blob_reader, &buffer)) |_| {
            std.debug.print("ERROR: stream did not end!\n", .{});
        }
    }

    // Reads back the incrementally written region through the whole-object
    // interface, proving the streamed bytes were committed
    const written = try obj.get("test_img1", &uuid, "john", .default);
    defer sloop.heap.free(written);
    std.debug.print("Streamed: {s}\n", .{written[2..7]});

    // Manages owners and access on the provisional object
    try obj.addOwner("test_img1", &uuid, "john", "doe", .default);
    try obj.addAccess("test_img1", &uuid, "john", "sam", .default);

    try obj.removeAccess("test_img1", &uuid, "john", "sam", .default);
    try obj.removeOwner("test_img1", &uuid, "john", "doe", .default);

    // Refuses to remove the last owner
    if (obj.removeOwner("test_img1", &uuid, "john", "john", .default)) |_| {
        std.debug.print("ERROR: last owner was removed!\n", .{});
    } else |err| {
        std.debug.print("Refused: {s}\n", .{@errorName(err)});
    }

    // Access is denied for entities outside the owner and access lists
    if (obj.get("test_img1", &uuid, "mallory", .default)) |_| {
        std.debug.print("ERROR: stranger read a private object!\n", .{});
    } else |err| {
        std.debug.print("Denied for mallory: {s}\n", .{@errorName(err)});
    }

    // Clearance overrides — `.owner` tightens the policy (jane is access-only
    // and loses read), `.access` relaxes it (jane may administer the object)
    if (obj.get("test_img1", &uuid, "jane", .owner)) |_| {
        std.debug.print("ERROR: access entity cleared by owner override!\n", .{});
    } else |err| {
        std.debug.print("Tightened: {s}\n", .{@errorName(err)});
    }

    try obj.addAccess("test_img1", &uuid, "jane", "doe", .access);

    var info3 = try obj.info("test_img1", &uuid, "doe", .access);
    defer info3.free();
    std.debug.print("Relaxed: {s} | {d} bytes\n", .
        {info3.value().name, info3.value().size});

    // Scans the object container (progressive row cursor)
    var cursor = try bucket.scan("test_img1");
    defer cursor.close();

    while (try cursor.next()) |row| {
        defer row.free();
        const scan_info = row.value();
        std.debug.print("Scan: {s} | {s} | {d} bytes\n", .
            {scan_info.uuid, scan_info.name, scan_info.size});
    }
}
